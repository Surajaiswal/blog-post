from django.urls import path
from django.contrib.auth import views as auth_views
from . import views
from users import views as views_users
from .views import PostListView, PostDetailView, PostCreateView, PostUpdateView, PostDeleteView, UserPostListView

urlpatterns = [
    path('', PostListView.as_view(), name='blog-home'),
    path('user/<str:username>', UserPostListView.as_view(), name='user-posts'),
    path('about/', views.about, name='blog-about'),
    path('register/', views_users.register, name="register"),
    path('login/', auth_views.LoginView.as_view(template_name='users/login.html'), name="Login"),
    path('logout/', auth_views.LogoutView.as_view(template_name='users/logout.html'), name="Logout"),
    path('profile/', views_users.profile, name="profile"),
    path('post/<int:pk>/', PostDetailView.as_view(), name='post-detail'),
    path('post/new/',PostCreateView.as_view(),name='post-create'),
    path('post/<int:pk>/update',PostUpdateView.as_view(),name='post-update'),
    path('post/<int:pk>/delete',PostDeleteView.as_view(),name='post-delete'),


    ]


from django.conf import settings
from django.conf.urls.static import static

if settings.DEBUG:
    urlpatterns +=  static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)